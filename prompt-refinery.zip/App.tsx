
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Zap, 
  Trash2, 
  Copy, 
  Check, 
  ChevronRight, 
  History as HistoryIcon, 
  LayoutDashboard,
  Cpu,
  ShieldCheck,
  ArrowRightLeft,
  Info,
  AlertTriangle,
  Code
} from 'lucide-react';
import { optimizePrompt } from './services/geminiService';
import { OptimizationResult, CompressionLevel, HistoryItem, OutputFormat, ModelStrategy } from './types';
import { AnalysisChart } from './components/AnalysisChart';
import { getSemanticDiagnostics } from './utils/semantic';

// GPT-Tokenizer for accurate counting
// @ts-ignore
import { encode } from 'https://esm.sh/gpt-tokenizer@2.1.2';

const App: React.FC = () => {
  const [input, setInput] = useState('');
  const [level, setLevel] = useState<CompressionLevel>(CompressionLevel.MEDIUM);
  const [format, setFormat] = useState<OutputFormat>(OutputFormat.XML);
  const [strategy, setStrategy] = useState<ModelStrategy>(ModelStrategy.UNIVERSAL);
  
  const [result, setResult] = useState<OptimizationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Real Token Counts
  const originalTokenCount = useMemo(() => {
    try { return encode(input).length; } catch { return Math.ceil(input.length / 4); }
  }, [input]);

  const diagnostics = useMemo(() => getSemanticDiagnostics(input), [input]);

  // Load history
  useEffect(() => {
    const saved = localStorage.getItem('prompt_refinery_history');
    if (saved) {
      try { setHistory(JSON.parse(saved)); } catch (e) { console.error("History parse failed"); }
    }
  }, []);

  // Save history
  useEffect(() => {
    localStorage.setItem('prompt_refinery_history', JSON.stringify(history.slice(0, 10)));
  }, [history]);

  const handleOptimize = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await optimizePrompt(input, level, format, strategy);
      
      // Calculate real tokenization for the result
      let finalResTokens = 0;
      try { finalResTokens = encode(res.refinedText).length; } catch { finalResTokens = Math.ceil(res.refinedText.length / 4); }
      
      const resWithRealTokens = {
        ...res,
        estimatedOriginalTokens: originalTokenCount,
        estimatedRefinedTokens: finalResTokens,
        savingsPercentage: ((originalTokenCount - finalResTokens) / originalTokenCount) * 100
      };

      setResult(resWithRealTokens);
      const newHistoryItem: HistoryItem = {
        ...resWithRealTokens,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now()
      };
      setHistory(prev => [newHistoryItem, ...prev]);
    } catch (err: any) {
      setError(err.message || 'Optimization failed.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 selection:bg-indigo-500/30">
      <nav className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-600 rounded-lg shadow-lg shadow-blue-500/20">
                <Code className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white flex items-center">
                Prompt<span className="text-blue-500">Refinery</span>
                <span className="ml-2 px-1.5 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-400 font-mono">v2.1</span>
              </span>
            </div>
            <div className="hidden md:flex items-center space-x-6 text-sm font-medium text-slate-400">
              <span className="flex items-center gap-1.5 text-xs text-slate-500">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                Engine: cl100k_base Active
              </span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-8 space-y-6">
            {/* Input Pane */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl transition-all hover:border-slate-700">
              <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-1.5 text-slate-300">
                    <Cpu className="w-4 h-4" />
                    <span className="text-sm font-bold uppercase tracking-wider">Raw Prompt</span>
                  </div>
                  {diagnostics.leaks > 0 && (
                    <div className="flex items-center space-x-1.5 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[10px] font-bold">
                      <AlertTriangle className="w-3 h-3" />
                      <span>{diagnostics.leaks} SEMANTIC LEAKS</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-xs text-slate-500 font-mono">Tokens: <b className="text-slate-300">{originalTokenCount.toLocaleString()}</b></span>
                  <button onClick={() => setInput('')} className="p-1.5 text-slate-500 hover:text-red-400 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your verbose, inefficient prompt here..."
                className="w-full h-80 bg-slate-950 p-6 text-slate-200 focus:outline-none resize-none mono text-sm leading-relaxed"
              />

              <div className="p-4 bg-slate-900/80 border-t border-slate-800 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Strategy</label>
                  <select 
                    value={strategy} 
                    onChange={(e) => setStrategy(e.target.value as ModelStrategy)}
                    className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 outline-none"
                  >
                    {Object.values(ModelStrategy).map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Output Syntax</label>
                  <select 
                    value={format} 
                    onChange={(e) => setFormat(e.target.value as OutputFormat)}
                    className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 outline-none"
                  >
                    {Object.values(OutputFormat).map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Compress</label>
                  <select 
                    value={level} 
                    onChange={(e) => setLevel(e.target.value as CompressionLevel)}
                    className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 outline-none"
                  >
                    {Object.values(CompressionLevel).map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <button
                  onClick={handleOptimize}
                  disabled={loading || !input.trim()}
                  className={`px-6 py-2.5 rounded-xl font-bold flex items-center justify-center space-x-2 transition-all shadow-lg ${
                    loading || !input.trim()
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-500 text-white active:scale-95'
                  }`}
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                  ) : (
                    <Zap className="w-4 h-4 fill-current" />
                  )}
                  <span>Refine</span>
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-900/20 border border-red-500/50 p-4 rounded-xl text-red-200 text-sm flex items-start space-x-3">
                <Info className="w-5 h-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Result Pane */}
            {result && !loading && (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
                  <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-green-500/10">
                    <div className="flex items-center space-x-2 text-green-400">
                      <ShieldCheck className="w-4 h-4" />
                      <span className="text-sm font-bold uppercase tracking-wider">Refined Output</span>
                    </div>
                    <button 
                      onClick={() => copyToClipboard(result.refinedText)}
                      className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        copied ? 'bg-green-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copied ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="p-6 bg-slate-950 text-green-50 mono text-sm leading-relaxed border-b border-slate-800 whitespace-pre-wrap">
                    {result.refinedText}
                  </div>
                  <div className="p-4 bg-slate-900 grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-2 rounded-lg bg-green-500/5 border border-green-500/10">
                      <p className="text-[10px] text-slate-500 font-bold uppercase">Reduction</p>
                      <p className="text-lg font-bold text-green-400">{result.savingsPercentage.toFixed(1)}%</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-blue-500/5 border border-blue-500/10">
                      <p className="text-[10px] text-slate-500 font-bold uppercase">New Tokens</p>
                      <p className="text-lg font-bold text-blue-400">{result.estimatedRefinedTokens}</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-slate-800/50 border border-slate-800">
                      <p className="text-[10px] text-slate-500 font-bold uppercase">Saved/1M Req</p>
                      <p className="text-lg font-bold text-slate-300">${((result.estimatedOriginalTokens - result.estimatedRefinedTokens) / 1000000 * 2.50).toFixed(2)}</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-slate-800/50 border border-slate-800">
                      <p className="text-[10px] text-slate-500 font-bold uppercase">Integrity</p>
                      <p className="text-lg font-bold text-slate-300">{result.semanticPreservationScore}%</p>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <ArrowRightLeft className="w-4 h-4" /> Refinery Logic Breakdown
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {result.removedSegments.map((seg, i) => (
                      <div key={i} className="group p-3 rounded-xl bg-slate-950 border border-slate-800 transition-colors hover:border-blue-500/30">
                        <p className="text-xs text-red-400 line-through mb-1.5 font-medium truncate italic" title={seg.text}>
                          &quot;{seg.text}&quot;
                        </p>
                        <p className="text-[11px] text-slate-400 leading-tight">
                          <span className="text-blue-400 font-bold mr-1 tracking-tighter">ACTION:</span>
                          {seg.reason}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-blue-600/5 border border-blue-500/20 rounded-2xl p-6">
               <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <LayoutDashboard className="w-5 h-5 text-blue-400" />
                  Refinery Stats
               </h3>
               {result ? (
                 <div className="space-y-6">
                    <AnalysisChart original={result.estimatedOriginalTokens} refined={result.estimatedRefinedTokens} />
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                       <p className="text-[11px] text-slate-400 leading-relaxed italic">
                         &quot;{result.explanation}&quot;
                       </p>
                    </div>
                 </div>
               ) : (
                 <div className="flex flex-col items-center justify-center py-12 text-slate-600 border-2 border-dashed border-slate-800 rounded-xl">
                    <Info className="w-8 h-8 mb-2 opacity-20" />
                    <p className="text-xs font-medium">Awaiting input for analysis...</p>
                 </div>
               )}
            </div>

            {diagnostics.repeatedPhrases.length > 0 && (
              <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-6">
                <h3 className="text-sm font-bold text-amber-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Semantic Bloat
                </h3>
                <div className="flex flex-wrap gap-2">
                  {diagnostics.repeatedPhrases.map((phrase, i) => (
                    <span key={i} className="px-2 py-1 rounded bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-400 mono">
                      {phrase}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-4">
              <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2 px-2">
                <HistoryIcon className="w-3 h-3" /> Recent Refineries
              </h3>
              <div className="space-y-2">
                {history.length === 0 ? (
                  <div className="p-8 text-center border border-slate-800/50 rounded-xl border-dashed">
                    <p className="text-[10px] text-slate-600 font-bold uppercase">No History</p>
                  </div>
                ) : (
                  history.map((item) => (
                    <div 
                      key={item.id} 
                      className="p-3 bg-slate-900/50 border border-slate-800 rounded-xl hover:bg-slate-900 transition-all group cursor-pointer"
                      onClick={() => setResult(item)}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-[9px] text-blue-400 font-bold tracking-widest">-{item.savingsPercentage.toFixed(0)}% TOKENS</span>
                        <span className="text-[9px] text-slate-600 font-mono">{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 font-mono">
                        {item.originalText}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

export default App;
