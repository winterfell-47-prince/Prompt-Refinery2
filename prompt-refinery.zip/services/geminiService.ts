
import { GoogleGenAI, Type } from "@google/genai";
import { OptimizationResult, CompressionLevel, OutputFormat, ModelStrategy } from "../types";

const API_KEY = process.env.API_KEY || "";

export const optimizePrompt = async (
  prompt: string,
  level: CompressionLevel,
  format: OutputFormat,
  strategy: ModelStrategy
): Promise<OptimizationResult> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const systemInstruction = `
    You are "Prompt Refinery", an elite Prompt Engineer specializing in token optimization for high-scale enterprise AI pipelines.
    Task: Re-sequence and optimize the provided prompt for maximum efficiency and clarity.
    
    STRATEGY CONTEXT: ${strategy}
    ${strategy === ModelStrategy.LEGAL ? `
    - SPECIAL FOCUS: LEGAL/REGULATORY. 
    - Strip "polite legalese" (e.g., "It is requested that", "We kindly ask you to ensure").
    - Retain all legal definitions, clause numbers, and jurisdictional references.
    - Convert verbose procedural instructions into concise logical constraints.
    ` : ''}

    REFINERY METHODOLOGY:
    1. RE-SEQUENCE: 
       - Identify the "Core Task". Place it at the top.
       - Identify "Constraints". Move these to the bottom.
       - Place "Context" or "Role" information between the Task and Constraints.
    2. STRIP FLUFF: Remove polite filler, meta-commentary, and linguistic redundancy.
    3. APPLY FORMAT: ${format} syntax.
    
    COMPRESSION LEVEL: ${level}
    
    Return the result in JSON format with refinedText, removedSegments (array of {text, reason}), explanation, and semanticPreservationScore (1-100).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            refinedText: { type: Type.STRING },
            removedSegments: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING },
                  reason: { type: Type.STRING }
                },
                required: ["text", "reason"]
              }
            },
            explanation: { type: Type.STRING },
            semanticPreservationScore: { type: Type.NUMBER }
          },
          required: ["refinedText", "removedSegments", "explanation", "semanticPreservationScore"]
        }
      }
    });

    const result = JSON.parse(response.text);
    const estOriginal = Math.ceil(prompt.length / 4);
    const estRefined = Math.ceil(result.refinedText.length / 4);
    const savings = ((estOriginal - estRefined) / estOriginal) * 100;

    return {
      originalText: prompt,
      refinedText: result.refinedText,
      estimatedOriginalTokens: estOriginal,
      estimatedRefinedTokens: estRefined,
      savingsPercentage: Math.max(0, savings),
      removedSegments: result.removedSegments,
      explanation: result.explanation,
      semanticPreservationScore: result.semanticPreservationScore
    };
  } catch (error) {
    console.error("Optimization failed:", error);
    throw new Error("Refinery process failed. Please check your prompt or connection.");
  }
};
